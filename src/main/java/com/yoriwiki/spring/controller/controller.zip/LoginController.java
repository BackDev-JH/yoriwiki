package com.yoriwiki.spring.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.yoriwiki.spring.domain.KakaoUserInfo;
import com.yoriwiki.spring.domain.UserVO;
import com.yoriwiki.spring.service.KakaoService;
import com.yoriwiki.spring.service.LoginService;
import com.yoriwiki.spring.service.SignUpService;

import lombok.extern.log4j.Log4j2;

@Log4j2
@Controller
@RequestMapping("/login/*")
public class LoginController {
	
	@Autowired
	private LoginService service;
	
	@Autowired
	private SignUpService service1;
	
	@Autowired
	private KakaoService kakaoService;
	
	
	@GetMapping("")
	public String login(UserVO vo) {
		vo.getUserEmail();
        vo.getUserPassword();
        log.info(vo);
        return "login";
        
	}
	
    @PostMapping("")
    public String login(Model model, UserVO vo, RedirectAttributes redirectAttributes,HttpSession session) {
        vo.getUserEmail();
        vo.getUserPassword();
        log.info(vo);
        
        UserVO user = service.logincount(vo);
        if (user != null) {
            session.setAttribute("user", user);
            System.out.println("user =" + user);
            return "redirect:/board/list";
        } else {
            redirectAttributes.addFlashAttribute("loginFailed", true);
            return "redirect:/login/";
        }
		
       
       // model.addAttribute("count",service.logincount(testuser));
        
    }   
    
    @GetMapping("kakao")
    public String kakaoLogin(@RequestParam("code") String code, HttpSession session, RedirectAttributes redirectAttributes) {
        try {
            // 인가코드를 사용하여 액세스 토큰 발급 받기
        	System.out.println("===========================");
        	System.out.println(code);
            String accessToken = kakaoService.getAccessToken(code);            
            if (accessToken == null) {
            	System.out.println("=================1==========");
                redirectAttributes.addFlashAttribute("loginFailed", true);
                return "redirect:/login/";
            }
            
            // 액세스 토큰을 사용하여 사용자 정보 받아오기
            KakaoUserInfo userInfo = kakaoService.getUserInfo(accessToken);
            if (userInfo == null) {
            	System.out.println("==============2=============");
                redirectAttributes.addFlashAttribute("loginFailed", true);
                return "redirect:/login/";
            }
            
            // 카카오 로그인으로 인증된 사용자의 이메일이 이미 등록되어 있는 경우 로그인 처리
            UserVO user = service.getUserByEmail(userInfo.getEmail());
            if (user != null) {
            	System.out.println("===========3================");
                session.setAttribute("user", user);
                System.out.println(user);
                System.out.println("user =" + user);
                return "redirect:/board/list";
            }
            
            // 카카오 로그인으로 인증된 사용자가 처음 가입하는 경우 자동으로 회원가입 처리
            UserVO newUser = new UserVO();
            newUser.setUserEmail(userInfo.getEmail());
            //newUser.setUSER_NAME(userInfo.getNickname());
            System.out.println("==================4=========");
            newUser.setUserPassword("1234"); // 비밀번호는 임의로 지정
            newUser.setPlatfomtype("kakao");
            newUser.setUserName(userInfo.getNickname());
            service1.signupcount(newUser);
            
            // 자동 회원가입 후 로그인 처리
            user = service.getUserByEmail(userInfo.getEmail());
            if (user != null) {
            	System.out.println("===============5============");
                session.setAttribute("user", user);
                System.out.println("user =" + user);
                return "redirect:/board/list";
            }
            
            redirectAttributes.addFlashAttribute("loginFailed", true);
            return "redirect:/login/";
        } catch (Exception e) {
            // 예외 처리
            redirectAttributes.addFlashAttribute("loginFailed", true);
            System.out.println("=============123213==============");
            return "redirect:/login/";
        }
    }

    @GetMapping("logout")
    public String logout(HttpSession session) {
        session.invalidate(); // 세션 무효화
        return "redirect:/board/list"; // 로그인 페이지로 리다이렉트
    }

}
